import 'package:flutter/material.dart';
import 'package:internship_task/order_screen.dart';


void main() {
  runApp(const OrderScreen());
}
